let images = ['img1.png', 'img2.png', 'img3.png', 'img4.png', 'img5.png'];
var arrayImage = [];
$(document).ready(function(){ 
    $('button').click(function(){
        if(!arrayImage.length){
            var div = document.createElement('div');
            var divImgge = [];
            div.classList.add("slider");
            div.style.width='200px';
            div.style.border='1px solid black';
            div.style.margin= '10px auto';
            document.body.append(div);
            for(var i = 0, I = images.length; i < I; i++)
            {
               arrayImage[i] = new Image ();
               divImgge[i] = document.createElement('div');
               arrayImage[i].src = "/images/"+images [i];
               divImgge[i].append(arrayImage[i])
               div.append(divImgge[i]);
           }
           $('.slider').slick({
                dots: true,
                infinite: true,
                slidesToShow: 1,
                slidesToScroll: 1,
                prevArrow: '<button class="slick-arrow slick-prev"><i class="fa fa-arrow-left">НАЗАД</i></button>',
                nextArrow: '<button class="slick-arrow slick-next"><i class="fa fa-arrow-right">ВПЕРЕД</i></button>',
            });
        }
    });  
});    
   
   