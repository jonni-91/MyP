# test02
В файле script.js массив с изображениями. Необходимо, используя js создать из них слайдер с помощью плагина slick (документация https://github.com/kenwheeler/slick)
